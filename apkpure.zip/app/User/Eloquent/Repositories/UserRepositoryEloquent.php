<?php

namespace App\User\Eloquent\Repositories;

use Modules\User\Eloquent\Repositories\UserRepositoryEloquent as EloquentRepository;

/**
 * Class UserRepositoryEloquent.
 *
 * @package namespace App\User\Eloquent\Repositories;
 */
class UserRepositoryEloquent extends EloquentRepository
{

}
