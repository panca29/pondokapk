<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AdvertisementRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AdvertisementRepository extends RepositoryInterface
{
    //
}
