<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppMoreDetailRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppMoreDetailRepository extends RepositoryInterface
{
    //
}
