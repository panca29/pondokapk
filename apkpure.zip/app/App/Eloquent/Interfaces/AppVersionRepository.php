<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppVersionRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppVersionRepository extends RepositoryInterface
{
    //
}
