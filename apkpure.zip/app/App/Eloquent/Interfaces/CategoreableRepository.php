<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoreableRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface CategoreableRepository extends RepositoryInterface
{
    //
}
