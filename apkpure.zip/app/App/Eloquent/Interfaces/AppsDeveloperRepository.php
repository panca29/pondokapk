<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppsDeveloperRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppsDeveloperRepository extends RepositoryInterface
{
    //
}
