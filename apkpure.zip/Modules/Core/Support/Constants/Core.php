<?php

namespace Modules\Core\Support\Constants;

/**
 *
 *
 * @package    DCM
 * @author     Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright  2018 (c) DCM
 * @version    Release: v1.0.0
 * @link       http://devcorpmanila.com
 */


class Core
{
    const VERSION = '1.0';
}