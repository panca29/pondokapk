<?php

namespace Modules\Category\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository.
 *
 * @package namespace Modules\Category\Eloquent\Interfaces;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}
