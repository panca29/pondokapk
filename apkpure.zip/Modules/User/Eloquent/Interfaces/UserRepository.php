<?php

namespace Modules\User\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository.
 *
 * @package namespace Modules\User\Eloquent\Interfaces;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
