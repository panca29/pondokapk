<?php

namespace Modules\User\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserDetailRepository.
 *
 * @package namespace Modules\User\Eloquent\Interfaces;
 */
interface UserDetailRepository extends RepositoryInterface
{
    //
}
