<?php

namespace Modules\Page\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PageRepository.
 *
 * @package namespace Modules\Page\Eloquent\Interfaces;
 */
interface PageRepository extends RepositoryInterface
{
    //
}
