<?php

return [
    'name' => 'Page',

    'status' => [
        'published' => 'published',
        'pending'   => 'pending',
        'is_draft'  => 'is_draft',
    ],


    'page_status_cache_key' => 'page_status'
];
